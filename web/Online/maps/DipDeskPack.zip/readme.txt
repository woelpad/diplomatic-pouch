Diplomacy Desktop Pack
----------------------

INTRODUCTION:
-------------
The Diplomacy Desktop Map is a kit to make your desktop turn into a clear, easy-to-use map.
You require a high resolution desktop (1024*768 and above should do the trick) although you can reduce
the map size for smaller resolutions.

Note also that the colors are set by the israeli diplomacy version so this might confuse people not 
used to them..

SIMPLE USAGE:
-------------
1. extract the zip file into a temporary directory (such as C:\TEMP).
2. Copy the contents of the 'dipicons' directory to c:\dipicons. create it if it doesn't exist.
3. Copy the contents of the 'desktop' directory to c:\windows\desktop or wherever you have windows
   installed.
4. Copy the contents of the 'windows' directory to c:\windows.
5. Set your desktop background to one of the diplomacy maps (I recommend the "old rug"), and set the 
   icons. All icons when double clicked will attempt to open d:\diplomacy\diplo.exe

"ADVANCED" USAGE:
-----------------
1. Put the contents of the 'diplo' directory wherever you like.
2. Follow step 4 of simple usage.
3. Create 22 shortcuts on your desktop to whatever program(s) you like. The best is just to copy one
   shortcut 21 times.
4. Give each shortcut the appropriate icon. It is described in the next section.
5. Same aa simple step 5.

ADDING TROOPS:
--------------
1. Create a new shortcut on your desktop to anything you want.
2. Right click the shortcut and choose 'properties'.
3. Click on 'Change icon'.
4. type the path where your icons are stored (default is c:\dipicons) and select the appropriate icon.
   The icons' names are composed as following: the first letter is the first letter in the empire name
   while the second letter is A for army and F for fleet. (e.g. c:\dipicons\RF.ico is a Russian Fleet.
5. Give your icon a name. I recommend the initial letter of the empire and a number (e.g. R1, R2 ..)

DELETING TROOPS:
----------------
heh... heh... This is an easy one.

THE MAPS:
---------
All 3 maps have "israeli" colors (the israeli diplomacy version has these colors).
1. Normal diplomacy map. This is a good map but it might become "crowded" because of all the text.
2. Blank diplomacy map. This is the same thing as no.1 except for no names in the map.
3. Blank "old rug" diplomacy map. The same as no.2 but with a fancy "rug" effect and increased
   brightness which give it an "old" look and makes troops more visible and eye-catching.

CONTACT ME:
-----------
I would like to give credit to the person who made the original map - but I don't know who he is since
I got this map from a friend. If you know - please tell me.
Any comments, suggestions and so on will be welcomed (if you would like to send a booby-trapped cat,
I will provide my snail mail address).
My name is Michael and my email is King_Itsik@hotmail.com

WANT TO IMPROVE THIS?
---------------------
You may change the map, the icons and the .lnk files as long as you give me credit for the original
idea. I also request that if you leave anything from this version, you will add this readme to your
desktop pack. Thank you.
